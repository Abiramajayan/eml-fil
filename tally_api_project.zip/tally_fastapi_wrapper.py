# tally_fastapi_wrapper.py
"""
Tiny FastAPI micro-service that accepts a Tally company backup ZIP,
extracts masters & vouchers with `tally-data-extractor`,
combines every resulting CSV into a single Excel workbook, and
streams the workbook back to the caller.
"""

import io
import tempfile
import zipfile
import subprocess
from pathlib import Path
from typing import List

import pandas as pd
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import FileResponse

app = FastAPI(title="Tally ZIP → Excel API", version="0.1.0")

TDE_BIN = "tde"  # assumes `tally-data-extractor` console script on PATH

def run(cmd: List[str], cwd: Path | None = None) -> None:
    res = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if res.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd)}\nSTDERR:\n{res.stderr}")

@app.post("/upload", summary="Upload Tally backup ZIP and get Excel workbook")
async def upload_tally_zip(file: UploadFile = File(...)) -> FileResponse:
    if not file.filename.endswith(".zip"):
        raise HTTPException(status_code=400, detail="Only .zip files accepted")

    with tempfile.TemporaryDirectory() as tmpdir_str:
        tmpdir = Path(tmpdir_str)
        zip_path = tmpdir / file.filename
        contents = await file.read()
        zip_path.write_bytes(contents)

        data_dir = tmpdir / "data"
        data_dir.mkdir()
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(data_dir)

        sqlite_path = tmpdir / "company.sqlite"
        run([TDE_BIN, "pull", str(data_dir), "--out", str(sqlite_path)])

        csv_dir = tmpdir / "csv"
        csv_dir.mkdir()
        run([TDE_BIN, "csv", str(sqlite_path), "--dest", str(csv_dir)])

        excel_bytes = io.BytesIO()
        with pd.ExcelWriter(excel_bytes, engine="openpyxl") as writer:
            for csv_file in csv_dir.glob("*.csv"):
                df = pd.read_csv(csv_file)
                sheet_name = csv_file.stem[:31]
                df.to_excel(writer, sheet_name=sheet_name, index=False)
        excel_bytes.seek(0)

        out_path = tmpdir / "tally_extracted.xlsx"
        out_path.write_bytes(excel_bytes.read())

        return FileResponse(
            path=out_path,
            filename="tally_extracted.xlsx",
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

@app.get("/", include_in_schema=False)
def root():
    return {
        "service": "Tally ZIP → Excel",
        "upload_endpoint": "/upload",
        "docs": "/docs",
    }